package Bank_Application;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Operation operlation = new Operation();
		operlation.bankinfo();
	}

}